package com.example.controller;

import java.time.LocalDateTime;

public class Message<T> {

        private LocalDateTime time;
        private String message;
        private T data;

        public Message() {
            // TODO Auto-generated constructor stub
        }

        public Message(LocalDateTime time, String message, T data) {
        super();
        this.time = time;
        this.message = message;
        this.data = data;
    }

        public LocalDateTime getTime() {
            return time;
        }

        public void setTime(LocalDateTime time) {
            this.time = time;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public T getData() {
            return data;
        }

        public void setData(T data) {
            this.data = data;
        }


}

