package com.example.model;

import java.util.UUID;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Objects;


@Document
public class Cat {
    @Id
    private String id;
    private String  catName;
    private Address location;
    private String description;
    private String ownerPhone;

    public Cat() {

        // Default constructor

    }

    public Cat(String catName, Address location, String description, String ownerPhone) {
        this.catName = catName;
        this.location = location;
        this.description = description;
        this.ownerPhone = ownerPhone;
    }

    public String getCatId() {
        return id;
    }

    public void setCatId(String id) {
        this.id = id;
    }

    public String getName() {
        return catName;
    }

    public void setName(String catName) {
        this.catName = catName;
    }

    public Address getLocation() {
        return location;
    }

    public void setLocation(Address location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cat cat)) return false;
        return this.getName().equals(((Cat) o).getName());
    }

    @Override
    public String toString() {
        return "Cat{" +
                "id=" + id +
                ", catName='" + catName + '\'' +
                ", location=" + location +
                ", description='" + description + '\'' +
                ", ownerPhone='" + ownerPhone + '\'' +
                '}';
    }
}
