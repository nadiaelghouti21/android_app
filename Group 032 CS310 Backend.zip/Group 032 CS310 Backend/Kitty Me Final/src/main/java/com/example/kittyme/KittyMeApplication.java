package com.example.kittyme;

import com.example.dao.CatDAO;
import com.example.model.Address;
import com.example.model.Cat;
import org.slf4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;




@SpringBootApplication(scanBasePackages = {"com.example.dao", "com.example.model", "com.example.controller"})
@EnableMongoRepositories(basePackages = {"com.example.dao"})
public class KittyMeApplication{

    @Autowired
    public CatDAO catDAO; // Why can't we autowire here?
    private static final Logger logger = LoggerFactory.getLogger(KittyMeApplication.class);
    public static void main(String[] args) {
        SpringApplication.run(KittyMeApplication.class, args);
    }

    //@Override
    //public void run(String... args) throws Exception {

//// Create addresses for cats
//        Address address1 = new Address("Istanbul", "33458", "Kadikoy");
//        Address address2 = new Address("Istanbul", "47292", "Tuzla");
//        Address address3 = new Address("Istanbul", "46829", "Uskudar");
//        Address address4 = new Address("Istanbul", "90283", "Beyoglu");
//        Address address5 = new Address("Bursa", "47924", "Bursa");
//        Address address6 = new Address("Ankara", "06520", "Cankaya");
//        Address address7 = new Address("Izmir", "35100", "Konak");
//        Address address8 = new Address("Antalya", "07070", "Konyaalti");
//
//// Create cat instances with corresponding addresses
//        Cat cat1 = new Cat("Simba", address1, "2-month-old grey cat. Enjoys being cuddled. Loves playing with toy mice.", "0531 193 19 23");
//        Cat cat2 = new Cat("Leo", address2, "1-year-old orange tabby. Enjoys lounging in sunny spots. Playful and curious.", "0555 555 55 55");
//        Cat cat3 = new Cat("Sam", address3, "3-month-old black and white kitten. Loves chasing laser pointers. Very energetic.", "0544 321 98 76");
//        Cat cat4 = new Cat("Selim", address4, "5-year-old Siamese cat. Enjoys napping in warm laps. Gentle and affectionate.", "0502 987 65 43");
//        Cat cat5 = new Cat("Wayne", address5, "4-month-old calico cat. Friendly and social. Enjoys meeting new people.", "0567 890 12 34");
//        Cat cat6 = new Cat("Mittens", address6, "6-month-old fluffy Persian cat. Enjoys grooming sessions. Playful and graceful.", "0530 111 22 33");
//        Cat cat7 = new Cat("Whiskers", address7, "2-year-old tuxedo cat. Enjoys birdwatching. Independent and curious.", "0541 333 44 55");
//        Cat cat8 = new Cat("Oliver", address8, "8-month-old gray and white kitten. Loves climbing on cat trees. Playful and mischievous.", "0552 678 90 12");
//
//// Create a list to store all cats
//        List<Cat> allCats = new ArrayList<>();
//
//// Add cats to the list
//        allCats.add(cat1);
//        allCats.add(cat2);
//        allCats.add(cat3);
//        allCats.add(cat4);
//        allCats.add(cat5);
//        allCats.add(cat6);
//        allCats.add(cat7);
//        allCats.add(cat8);
//
//// Insert the list of cats into the catDAO (assuming catDAO is an appropriate data access object)
//        catDAO.insert(allCats);

   // }
}

