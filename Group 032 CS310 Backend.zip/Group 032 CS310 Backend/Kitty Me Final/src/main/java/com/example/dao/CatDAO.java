package com.example.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.model.Cat;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CatDAO extends MongoRepository<Cat, String> {
    @Query("{'catName': ?0}")
    public List<Cat> findByName(String catName);

    @Query("{'location.city': { $regex: ?0, $options: 'i' }}")
    public List<Cat> findByCityIgnoreCase(String city);

    @Query("{ 'catName' : { $regex: ?0, $options: 'i' } }")
    public List<Cat> findByNameContainsIgnoreCase(String catName);

    @Query("{catName:{$regex:?0,$options:'i'}}")
    public List<Cat> findByNameParam1(String name);

    @Query("{'address.city':?0}")
    public List<Cat> findByCityWithParam(String city);

    @Query("{'name': {$regex: ?0}}")
    List<Cat> findByCaseInsensitiveNameContaining(String name);

}
