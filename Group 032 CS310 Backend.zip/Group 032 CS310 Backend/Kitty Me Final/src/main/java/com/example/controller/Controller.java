package com.example.controller;

import com.example.dao.CatDAO;
import com.example.model.Cat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/kittyme")
public class Controller {

    @Autowired
    private CatDAO catDAO;

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome to Kitty Me!";
    }

    // Major requests: Get and Post
    // in order to acces this: http://localhost:8080/kittyme/displaycats Just type it into the browser
    @GetMapping("/displaycats")
    public ResponseEntity<List<Message<Cat>>> displayCats() {
        List<Cat> allCats = catDAO.findAll();

        if (allCats.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        List<Message<Cat>> catResponse = new ArrayList<>();
        Integer i = 0;
        for (Cat cat : allCats) {
            i++;
            catResponse.add(new Message<>(LocalDateTime.now(), "Cat " + i,  cat));
        }

        return new ResponseEntity<>(catResponse, HttpStatus.OK);
    }

    @GetMapping("/findcat/{name}")
    public ResponseEntity<List<Cat>> findCatByName(@PathVariable("name") String name) {
        List<Cat> foundCat = catDAO.findByName(name);

        if (foundCat != null) {
            return new ResponseEntity<>(foundCat, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/updateCatName/{oldName}/{newName}")
    public ResponseEntity<String> updateCatName(
            @PathVariable("oldName") String oldName,
            @PathVariable("newName") String newName) {
        Cat catToUpdate;
        List<Cat> cats = catDAO.findByName(oldName);

        catToUpdate = cats.stream().findFirst().orElse(null);

        if (catToUpdate != null) {
            catToUpdate.setName(newName);
            String id = catToUpdate.getCatId();
            catDAO.deleteById(id);
            catDAO.insert(catToUpdate);
                return new ResponseEntity<>("Cat name updated successfully", HttpStatus.OK);
            }

        return new ResponseEntity<>("Cat with name '" + oldName + "' not found or unable to update", HttpStatus.NOT_FOUND);

    }

    @GetMapping("/findbycity/{city}")
    public ResponseEntity<List<Cat>> findCatsByCity(@PathVariable String city) {
        List<Cat> cats = catDAO.findByCityIgnoreCase(city);
        if (!cats.isEmpty()) {
            return new ResponseEntity<>(cats, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/phone/{name}")
    public ResponseEntity<List<String>> getPhoneNum(@PathVariable String name){
        List<Cat> cats = catDAO.findByNameContainsIgnoreCase(name);
        List<String> phoneNumbers = new ArrayList<>();
        if (!cats.isEmpty()){
            for (Cat cat : cats) {
                phoneNumbers.add(cat.getOwnerPhone());
            }
            return new ResponseEntity<>(phoneNumbers, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("/describe/{name}")
    public ResponseEntity<List<String>> getDescription(@PathVariable String name){
        List<Cat> cats = catDAO.findByNameContainsIgnoreCase(name);
        List<String> descriptons = new ArrayList<>();
        if (!cats.isEmpty()){
            for (Cat cat : cats) {
                descriptons.add(cat.getDescription());
            }
            return new ResponseEntity<>(descriptons, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

}